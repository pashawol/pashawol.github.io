import './polyfills.js';
import IMask from './imask.js';
export default IMask;
