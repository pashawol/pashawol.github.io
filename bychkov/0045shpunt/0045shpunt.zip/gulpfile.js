var gulp           = require('gulp'),
		gutil          = require('gulp-util' ),
		sass           = require('gulp-sass'),
		browserSync    = require('browser-sync'),
		concat         = require('gulp-concat'),
		uglify         = require('gulp-uglify'),
		cleanCSS       = require('gulp-clean-css'),
		rename         = require('gulp-rename'),
		del            = require('del'),
		imagemin       = require('gulp-imagemin'),
		cache          = require('gulp-cache'),
		autoprefixer   = require('gulp-autoprefixer'),
		bourbon        = require('node-bourbon'),
		ftp            = require('vinyl-ftp'),
		notify         = require("gulp-notify"), 
		pug            = require("gulp-pug"),
		emitty				 = require('emitty').setup('sourse/pug/pages', 'pug'),
		combineMq  = require('gulp-combine-mq'),
		sourcemaps = require('gulp-sourcemaps'), 
		gulpif 					= require('gulp-if'),
		envDev 					= false,
		config					= {
			sourse: 'sourse',
				public: 'public',
				jsVar: 'sourse/libs/',
				sassVAr: 'sourse/sass/**/*',
		}
// Скрипты проекта
// "gulp": "^3.9.1",


gulp.task('scripts', function() {
	return gulp.src([
		'sourse/libs/jquery/dist/jquery.min.js',
		'sourse/libs/magnificPopup/jquery.magnific-popup.min.js',
		//'sourse/libs/bootstrap-sass/assets/javascripts/bootstrap.min.js',
	 //'sourse/libs/jQueryFormStyler-master/jquery.formstyler.min.js',
		'sourse/libs/jquery.inputmask.bundle.min.js',
 
		'sourse/libs/jquery.inputmask.js',
		'sourse/libs/slick/slick.js',

		//'app/js/common.js', // Всегда в конце
		])
	.pipe(concat('scripts.min.js'))
	.pipe(uglify())
	.pipe(gulp.dest('public/js'))
	.pipe(browserSync.reload({stream: true}));
});

gulp.task('browser-sync', function() {
	browserSync({
		server: {
			baseDir: 'public'
		},
		notify: false,
		// tunnel: true,
		// tunnel: "projectmane", //Demonstration page: http://projectmane.localtunnel.me
	});
});

gulp.task('sass', function() {
	return gulp.src('sourse/sass/main.scss')
	.pipe(sourcemaps.init())
	.pipe(sass({
		includePaths: bourbon.includePaths
	}).on("error", notify.onError()))
	//.pipe(gulpif(envDev, sourcemaps.write({includeContent: false, sourceRoot: '/public'})))
	.pipe(gulpif(!envDev, combineMq()))
	.pipe(rename({suffix: '.min', prefix : ''}))
	.pipe(autoprefixer(['last 15 versions']))
	.pipe(cleanCSS())
	.pipe(sourcemaps.write())
	.pipe(gulp.dest('public/css'))
	.pipe(browserSync.reload({stream: true}));
});

gulp.task('templates', () =>
	new Promise((resolve, reject) => {
		emitty.scan(global.emittyChangedFile).then(() => {
			gulp.src('sourse/pug/pages/*.pug')
				.pipe(gulpif(global.watch, emitty.filter(global.emittyChangedFile)))
				.pipe(pug({ pretty: true }).on("error", notify.onError())) 
				.pipe(gulp.dest('public'))
				.on('end', resolve)
				.on('error', reject)
				.pipe(browserSync.reload({stream: true}));
		});
	})
);

// Your "watch" task
gulp.task('watch', ['sass', 'scripts','templates','browser-sync'], () => {
	// Shows that run "watch" mode
	global.watch = true;
	gulp.watch('sourse/sass/**/*.css', ['sass']);
	gulp.watch('sourse/sass/**/*.scss', ['sass']);
	gulp.watch('sourse/sass/**/*.sass', ['sass']);
	gulp.watch('sourse/pug/blocks/**/*.scss', ['sass']);
	gulp.watch('public/js/common.js', ['scripts']);
	gulp.watch('sourse/pug/**/*.pug', ['templates'])
		.on('all', (event, filepath) => {
			global.emittyChangedFile = filepath;
		});
		//gulp.watch('public/*.html', browserSync.reload);
});




gulp.task('imagemin', function() {
	return gulp.src('public/img/**/*')
	.pipe(cache(imagemin()))
	.pipe(gulp.dest('dist/img')); 
});

gulp.task('build', ['removedist', 'imagemin', 'sass', 'scripts',], function() {

	var buildFiles = gulp.src([
		'public/*.html',
		'public/.htaccess',
		]).pipe(gulp.dest('dist'));

	var buildCss = gulp.src([
		'public/css/main.min.css',
		]).pipe(gulp.dest('dist/css'));

	var buildJs = gulp.src([
		'public/js/scripts.min.js',
		]).pipe(gulp.dest('dist/js'));
var buildJs = gulp.src([
		'public/js/common.js',
		]).pipe(gulp.dest('dist/js'));

	var buildFonts = gulp.src([
		'public/fonts/**/*',
		]).pipe(gulp.dest('dist/fonts'));

});

gulp.task('deploy', function() {

	var conn = ftp.create({
		host:      'hostname.com',
		user:      'username',
		password:  'userpassword',
		parallel:  10,
		log: gutil.log
	});

	var globs = [
	'dist/**',
	'dist/.htaccess',
	];
	return gulp.src(globs, {buffer: false})
	.pipe(conn.dest('/path/to/folder/on/server'));

});

gulp.task('removedist', function() { return del.sync('dist'); });
gulp.task('clearcache', function () { return cache.clearAll(); });

gulp.task('default', ['watch']);
